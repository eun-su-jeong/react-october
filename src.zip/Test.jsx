import { useState, useRef, useEffect } from 'react';
import './Test.scss';

export default function Test() {
	return <div className='Test'>Test</div>;
}
// 스니펫 테스트
